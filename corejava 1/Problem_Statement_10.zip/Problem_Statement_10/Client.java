package Problem_Statement_10;

public class Client {
public static boolean isShuffling(String first, String second, String third)
{
if (first.length() == 0 && second.length() == 0 && third.length() == 0) {
return true;
}
if (third.length() == 0) {
return false;
}
if (first.length() != 0 && third.charAt(0) == first.charAt(0)) {
return isShuffling(first.substring(1), second, third.substring(1));
}
if (second.length() != 0 && third.charAt(0) == second.charAt(0)) {
return isShuffling(first, second.substring(1), third.substring(1));}
return false;
}
 public static void main(String[] args)
{
String first = "pqr";
String second = "lmno";
String third = "plmrqon";
if (isShuffling(first, second, third)) {
System.out.print("true: given string is a valid shuffle of first and second string");
}
else {
System.out.print("false: third string is not valid shuffle of first and second string");
}
}
}
